let speed = 20;
let scale = 0.5; // Image scale (I work on 1080p monitor)
let canvas;
let ctx;
let logoColor;
let updater;
let beki = document.getElementById("onoff");
let szingomb = document.getElementById("szin");
let dorombolas = new Audio('hang/doromb.mp3');

var animated = false;
var szinbe = false;

let dvd = {
    x: 30,
    y: 0,
    xspeed: 10,
    yspeed: 10,
    img: new Image()
};

dvd.img.src = 'főoldal/morcica.jpg';

function gombState() {
    if (animated)
        beki.innerHTML = "Ki";
    else
        beki.innerHTML = "Be";
    if (szinbe)
        szingomb.innerHTML = "Szín Ki";
    else
        szingomb.innerHTML = "Szín Be";
}

function start(gomb) {
    console.log("asd");
    animated = !animated;
    gombState();
    clearTimeout(updater);
    update();
}

function reset() {
    if (dorombolas) {
        dorombolas.pause();
        dorombolas.currentTime = 0;
    }
    animated = false;
    dvd.x = 30;
    dvd.y = 0;
    dvd.xspeed = 10;
    dvd.yspeed = 10;
    gombState();
    clearTimeout(updater);
    update();
}

function doromb() {
    animated = !animated;
    dvd.x = 30;
    dvd.y = 0;
    dvd.xspeed = -30;
    dvd.yspeed = -30;
    gombState();
    dorombolas.play();
    clearTimeout(updater);
    update();
}

function szin() {
    szinbe = !szinbe;
    gombState();
    clearTimeout(updater);
    update();
}

function change(slider) {
    speed = document.getElementById("speedinput").value;
    clearTimeout(updater);
    update();
}

function dspeed() {
    update();
}

(function main() {
    canvas = document.getElementById("tv-screen");
    ctx = canvas.getContext("2d");
    canvas.style.backgroundColor = "transparent";

    canvas.width = window.innerWidth - 20;
    canvas.height = window.innerHeight;

    pickColor();
    update();
})();

function update() {
    updater = setTimeout(() => {
        //Draw the canvas background
        //ctx.fillStyle = '#8f3f3f';
        ctx.fillStyle = '#8f3f3f';
        if (szinbe) {
            ctx.fillStyle = logoColor;
        }
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        //Draw DVD Logo and his background
        ctx.fillRect(dvd.x, dvd.y, dvd.img.width * scale, dvd.img.height * scale);
        ctx.drawImage(dvd.img, dvd.x, dvd.y, dvd.img.width * scale, dvd.img.height * scale);
        dvd.x += dvd.xspeed;
        dvd.y += dvd.yspeed;
        if (animated) {
            //Move the logo
            //Check for collision 
            checkHitBox();
            update();
        }
    }, speed)
}

//Check for border collision
function checkHitBox() {
    if (dvd.x + dvd.img.width * scale >= canvas.width || dvd.x <= 0) {
        dvd.xspeed *= -1;
        pickColor();
    }

    if (dvd.y + dvd.img.height * scale >= canvas.height || dvd.y <= 0) {
        dvd.yspeed *= -1;
        pickColor();
    }
}

//Pick a random color in RGB format
function pickColor() {
    r = Math.random() * (254 - 0) + 0;
    g = Math.random() * (254 - 0) + 0;
    b = Math.random() * (254 - 0) + 0;

    logoColor = 'rgb(' + r + ',' + g + ', ' + b + ')';
}

(function() {
    function getParams(startAttr, speedAttr) {
        let start = 0;
        let speed = 250;

        let scripts = window.document.getElementsByTagName('script');

        for (let i = 0; i < scripts.length; i++) {
            if (scripts[i].src.indexOf('title-scroll.js') !== -1) {
                if (scripts[i].getAttribute(startAttr) !== null && scripts[i].getAttribute(startAttr) !== "") {
                    start = scripts[i].getAttribute(startAttr);
                }

                if (scripts[i].getAttribute(speedAttr) !== null && scripts[i].getAttribute(speedAttr) !== "") {
                    speed = scripts[i].getAttribute(speedAttr);
                }

                break;
            }
        }

        return [start, speed];
    }

    window.addEventListener('load', () => {
        let [start, speed] = getParams('data-start', 'data-speed');

        let title = document.title + "Pythonban 2 sor ---- ";
        let i = 0;

        setTimeout(function() {
            setInterval(function() {
                document.title = title.substr(i, title.length) + title.substr(0, i);
                i = (i + 1) % title.length;
            }, speed);
        }, start);
    });
})();